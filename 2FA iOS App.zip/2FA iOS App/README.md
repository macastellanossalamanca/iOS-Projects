# Miguel Castellanos

## 2FA Authentication App

- This project is a basic replica of the app Authy from Twilio, which gets through a view the issuer and secrets in order to generate a OTP.
- The secrets used to generate the codes are takes from [Twilio Verify Api](https://verify-totp-1637-ugqh6t.twil.io/index.html), where the OTP's can be verified
- It uses MVVM Architecture, and uses data binding through observable pattern. Besides, It persists data using CoreData and uses Delegate Pattern to manage different features.
- Image for navigation bar and logo are authored by Twilio

# How it works

https://user-images.githubusercontent.com/44925834/198816152-c29e4e7a-bbc1-4610-900a-a355381fdeb1.mov

